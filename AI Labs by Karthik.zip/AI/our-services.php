<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Eduxon HTML-5 Template</title>
    <!-- favicon -->
    <link rel="icon" href="assets/img/favicon.png" sizes="20x20" type="image/png">
    <!-- animate -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- magnific popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!-- Nice Select -->
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <!-- Odomiters css -->
    <link rel="stylesheet" href="assets/css/odometer.css">
    <!-- fontawesome -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <!-- Slick Slider -->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive Css -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<!-- Developed by Shahadat Hossain -->

<body>
    <!-- preloader area start -->
    <div class="preloader" id="preloader">
        <div class="preloader-inner">
            <div class="loader">
            </div>
        </div>
    </div>
    <!-- preloader area end -->

    <!--  search Popup start -->
    <div class="body-overlay" id="body-overlay"></div>
    <div class="search-popup" id="search-popup">
        <form action="index.html" class="search-form">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Search.....">
            </div>
            <button class="close-btn border-none"><i class="fas fa-search"></i></button>
        </form>
    </div>
    <!-- Search Popup End -->

    <main class="page-wrapper">
        <!-- nav area start here -->
        <div class="nav-area-wrapper-relative">
            <nav class="navbar navbar-area navbar-expand-lg navigation-style-02">
                <div class="container custom-container custom-container-01">
                    <div class="responsive-menu">
                        <div class="logo-wrapper">
                            <a href="index.html" class="logo">
                                <img src="assets/img/Logos/logo-black.svg" alt="">
                            </a>
                        </div>
                        <button class="navbar-toggler navbar-bs-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#themeim_main_menu" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse" id="themeim_main_menu">
                        <ul class="navbar-nav">
                            <li class="menu-item-has-children">
                                <a href="#0">Home</a>
                                <ul class="sub-menu">
                                    <li><a href="index.html">Home One</a></li>
                                    <li><a href="index-02.html">Home Two</a></li>
                                    <li><a href="index-03.html">Home Three</a></li>
                                </ul>
                            </li>

                            <li><a href="about-us.html">About Us</a></li>

                            <li class="menu-item-has-children current-menu-item">
                                <a href="#">Pages</a>
                                <ul class="sub-menu">
                                    <li><a href="Our-services.html">Our Services</a></li>
                                    <li><a href="services-details.html">Services Details</a></li>
                                    <li><a href="our-team.html">Team</a></li>
                                    <li><a href="instructors.html">Instructors</a></li>
                                    <li><a href="about-instructor.html">About Instructor</a></li>
                                    <li><a href="country-details.html">Country Details</a></li>
                                    <li><a href="all-course.html">All Course</a></li>
                                    <li><a href="all-course-widget.html">All Course with widget</a></li>
                                    <li><a href="course-details.html">Course Details</a></li>
                                    <li><a href="apply-online.html">Apply Online</a></li>
                                    <li><a href="shop-cart.html">Shop Cart</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="404.html">404</a></li>
                                    <li><a href="cart-empty.html">Cart Empty</a></li>
                                </ul>
                            </li>

                            <li class="menu-item-has-children">
                                <a href="#">Blog</a>
                                <ul class="sub-menu">
                                    <li><a href="blog.html">Blog</a></li>
                                    <li><a href="blog-classic.html">Blog Classic</a></li>
                                    <li><a href="blog-details.html">Blog Single</a></li>
                                </ul>
                            </li>

                            <li><a href="contact-us.html">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="nav-right-content">
                        <div class="icon-part">
                            <ul>
                                <li id="search"><a href="#"><img src="assets/img/icon/search-icon.png" alt=""></a></li>
                            </ul>
                        </div>
                        <div class="btn-wrap">
                            <a href="#" class="btn-common nav-btn">Free consultation</a>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
        <!-- nav area end here -->

        <!-- about page start here  -->
        <div class="out-services-wrapper single-page-section-top-space single-page-section-bottom-space">

            <!-- breadcrumb area start here  -->
            <div class="breadcrumb-wrap style-01">
                <div class="container custom-container-01">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcrumb-content">
                                <h3 class="title">Our services</h3>
                                <p class="details">Lorem ipsum dummy text are used in this section</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- breadcrumb area end here  -->

            <!-- teem area start here  -->
            <section class="our-services-area-wrapper">
                <div class="our-team-inner">
                    <div class="container custom-container-01">
                        <div class="row column-gap-50">
                            <div class="col-md-6 col-lg-4">
                                <div class="single-our-services-item style-01">
                                    <div class="icon">
                                        <img src="assets/img/services/icon/01.png" alt="team image">

                                    </div>

                                    <div class="content">
                                        <h4 class="title">
                                            <a href="#" tabindex="-1">Career Counseling</a>
                                        </h4>

                                        <p class="paragraph">Lorem Innovate systematically, continuously successfully.
                                            Lorem ipsum dummy lorem
                                            ipsum dummy text are used here.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-4">
                                <div class="single-our-services-item style-01">
                                    <div class="icon">
                                        <img src="assets/img/services/icon/02.png" alt="team image">

                                    </div>

                                    <div class="content">
                                        <h4 class="title">
                                            <a href="#" tabindex="-1">Scholarship</a>
                                        </h4>

                                        <p class="paragraph">Lorem Innovate systematically, continuously successfully.
                                            Lorem ipsum dummy lorem
                                            ipsum dummy text are used here.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-4">
                                <div class="single-our-services-item style-01">
                                    <div class="icon">
                                        <img src="assets/img/services/icon/03.png" alt="team image">

                                    </div>

                                    <div class="content">
                                        <h4 class="title">
                                            <a href="#" tabindex="-1">Admission Guidance</a>
                                        </h4>

                                        <p class="paragraph">Lorem Innovate systematically, continuously successfully.
                                            Lorem ipsum dummy lorem
                                            ipsum dummy text are used here.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-4">
                                <div class="single-our-services-item style-01">
                                    <div class="icon">
                                        <img src="assets/img/services/icon/04.png" alt="team image">

                                    </div>

                                    <div class="content">
                                        <h4 class="title">
                                            <a href="#" tabindex="-1">Financial Support</a>
                                        </h4>

                                        <p class="paragraph">Lorem Innovate systematically, continuously successfully.
                                            Lorem ipsum dummy lorem
                                            ipsum dummy text are used here.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-4">
                                <div class="single-our-services-item style-01">
                                    <div class="icon">
                                        <img src="assets/img/services/icon/05.png" alt="team image">

                                    </div>

                                    <div class="content">
                                        <h4 class="title">
                                            <a href="#" tabindex="-1">Visa & Travel Guide</a>
                                        </h4>

                                        <p class="paragraph">Lorem Innovate systematically, continuously successfully.
                                            Lorem ipsum dummy lorem
                                            ipsum dummy text are used here.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-4">
                                <div class="single-our-services-item style-01">
                                    <div class="icon">
                                        <img src="assets/img/services/icon/06.png" alt="team image">

                                    </div>

                                    <div class="content">
                                        <h4 class="title">
                                            <a href="#" tabindex="-1">Job Funding</a>
                                        </h4>

                                        <p class="paragraph">Lorem Innovate systematically, continuously successfully.
                                            Lorem ipsum dummy lorem
                                            ipsum dummy text are used here.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </section>
            <!-- teem area end here  -->
        </div>
        <!-- about page end here  -->

        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            footer area start Here
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <footer class="footer-area style-01">
            <div class="footer-top">
                <div class="container custom-container-01">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="footer-widget widget widget_subscribe">
                                <div class="subscibe-wrapper">
                                    <div class="content-wrap">
                                        <div class="icon">
                                            <img src="assets/img/icon/newslater.png" alt="">
                                        </div>
                                        <div class="content">
                                            <h4 class="title">Subscribe our newsletter</h4>
                                            <p>Enter your mail address to get our updates, offer and study abroad
                                                related all updates</p>
                                        </div>

                                    </div>
                                    <div class="subscribe-form">
                                        <div class="form-group">
                                            <input type="text" name="fname" placeholder="Enter your Email..."
                                                class="form-control" required="" aria-required="true">
                                            <div class="btn-wrap">
                                                <a href="service-single.html" class="subscribe-btn">
                                                    <img src="assets/img/icon/bell.png" alt="">subscribe</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="footer-middle">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Important Links</h4>
                                    <ul>
                                        <li><a href="#">Terms and conditions</a></li>
                                        <li><a href="#">Disclaimer and copyright</a></li>
                                        <li><a href="#">Cookie policy</a></li>
                                        <li><a href="#">Privacy policy</a></li>
                                        <li><a href="#">Equality and diversity</a></li>
                                        <li><a href="#">Complaints procedure</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Site Highlight</h4>
                                    <ul>
                                        <li><a href="#">Student videos</a></li>
                                        <li><a href="#">Photo gallery</a></li>
                                        <li><a href="#">TSC prospectus</a></li>
                                        <li><a href="#">Student newsletter</a></li>
                                        <li><a href="#">Student portal</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Help Center</h4>
                                    <ul>
                                        <li><a href="#">Courses</a></li>
                                        <li><a href="#">How to apply for admission</a></li>
                                        <li><a href="#">Admission Documents</a></li>
                                        <li><a href="#">Frequently asked questions</a></li>
                                        <li><a href="#">Student accommodation</a></li>
                                        <li><a href="#">Student Jobs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Services</h4>
                                    <ul>
                                        <li><a href="#">Counselling</a></li>
                                        <li><a href="#">Test Preparation</a></li>
                                        <li><a href="#">Admission</a></li>
                                        <li><a href="#">Education Loan</a></li>
                                        <li><a href="#">Visa Processing</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Location</h4>
                                    <ul class="contact_info_list">
                                        <li class="single-info-item">
                                            <div class="icon">
                                                <img src="assets/img/icon/location-02.png" alt="">
                                            </div>
                                            <div class="details">
                                                8502 Preston Rd. Inglewood, Maine Bangladesh
                                            </div>
                                        </li>
                                        <li class="single-info-item">
                                            <div class="icon me-4">
                                                <img src="assets/img/icon/edu-award.png" alt="">
                                            </div>
                                            <div class="icon">
                                                <img src="assets/img/icon/iso.png" alt="">
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-area">
                <div class="container custom-container-01">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="copyright-area-inner">
                                <p>© 2022 eduxon. All rights reserved | Developed By <span>Themeim</span></p>
                                <div class="footer-social-area">
                                    <ul class="social-icon-02">
                                        <li><a href="#0"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#0"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="#0"><i class="fab fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            footer area End Here
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    </main>

    <!-- back to top area start -->
    <!-- <div class="back-to-top">
        <span class="back-top"><i class="fa fa-angle-up"></i></span>
    </div> -->
    <!-- back to top area end -->

    <!-- Jquery Js -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <!-- bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/jquery.magnific-popup.js"></script>
    <!-- wow -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Nice Select -->
    <script src="assets/js/jquery.nice-select.js"></script>
    <!-- countdown -->
    <script src="assets/js/jquery.countdown.min.js"></script>
    <!-- Odomiters -->
    <script src="assets/js/odometer.min.js"></script>
    <!-- Viewport Js -->
    <script src="assets/js/viewport.jquery.js"></script>
    <!-- slick Js -->
    <script src="assets/js/slick.min.js"></script>
    <!-- main js -->
    <script src="assets/js/main.js"></script>

</body>

</html>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  