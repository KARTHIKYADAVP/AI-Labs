<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Eduplan HTML-5 Template</title>
    <!-- favicon -->
    <link rel="icon" href="assets/img/favicon.png" sizes="20x20" type="image/png">
    <!-- animate -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- magnific popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!-- Nice Select -->
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <!-- Odomiters css -->
    <link rel="stylesheet" href="assets/css/odometer.css">
    <!-- fontawesome -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <!-- Slick Slider -->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!-- Date Picker -->
    <link rel="stylesheet" href="assets/css/datepicker.min.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive Css -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<!-- Developed by Shahadat Hossain -->

<body>
    <!-- preloader area start -->
    <div class="preloader" id="preloader">
        <div class="preloader-inner">
            <div class="loader">
            </div>
        </div>
    </div>
    <!-- preloader area end -->

    <!--  search Popup start -->
    <div class="body-overlay" id="body-overlay"></div>
    <div class="search-popup" id="search-popup">
        <form action="index.html" class="search-form">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Search.....">
            </div>
            <button class="close-btn border-none"><i class="fas fa-search"></i></button>
        </form>
    </div>
    <!-- Search Popup End -->

    <main class="page-wrapper">
        <!-- nav area start here -->
        <div class="nav-area-wrapper-relative">
            <nav class="navbar navbar-area navbar-expand-lg navigation-style-02">
                <div class="container custom-container custom-container-01">
                    <div class="responsive-menu">
                        <div class="logo-wrapper">
                            <a href="index.html" class="logo">
                                <img src="assets/img/Logos/logo-black.svg" alt="">
                            </a>
                        </div>
                        <button class="navbar-toggler navbar-bs-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#themeim_main_menu" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse" id="themeim_main_menu">
                        <ul class="navbar-nav">
                            <li class="menu-item-has-children">
                                <a href="#0">Home</a>
                                <ul class="sub-menu">
                                    <li><a href="index.html">Home One</a></li>
                                    <li><a href="index-02.html">Home Two</a></li>
                                </ul>
                            </li>

                            <li><a href="about-us.html">About Us</a></li>

                            <li class="menu-item-has-children current-menu-item">
                                <a href="#">Pages</a>
                                <ul class="sub-menu">
                                    <li><a href="Our-services.html">Our Services</a></li>
                                    <li><a href="services-details.html">Services Details</a></li>
                                    <li><a href="our-team.html">Team</a></li>
                                    <li><a href="instructors.html">Instructors</a></li>
                                    <li><a href="about-instructor.html">About Instructor</a></li>
                                    <li><a href="country-details.html">Country Details</a></li>
                                    <li><a href="all-course.html">All Course</a></li>
                                    <li><a href="all-course-widget.html">All Course with widget</a></li>
                                    <li><a href="course-details.html">Course Details</a></li>
                                    <li><a href="apply-online.html">Apply Online</a></li>
                                    <li><a href="shop-cart.html">Shop Cart</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="404.html">404</a></li>
                                    <li><a href="cart-empty.html">Cart Empty</a></li>
                                </ul>
                            </li>

                            <li class="menu-item-has-children">
                                <a href="#">Blog</a>
                                <ul class="sub-menu">
                                    <li><a href="blog.html">Blog</a></li>
                                    <li><a href="blog-classic.html">Blog Classic</a></li>
                                    <li><a href="blog-details.html">Blog Single</a></li>
                                </ul>
                            </li>

                            <li><a href="contact-us.html">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="nav-right-content">
                        <div class="icon-part">
                            <ul>
                                <li id="search"><a href="#"><img src="assets/img/icon/search-icon.png" alt=""></a></li>
                            </ul>
                        </div>
                        <div class="btn-wrap">
                            <a href="#" class="btn-common nav-btn">Free consultation</a>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
        <!-- nav area end here -->

        <!-- about page start here  -->
        <div class="contact-us-wrapper single-page-section-top-space single-page-section-bottom-space">
            <!-- breadcrumb area start here  -->
            <div class="breadcrumb-wrap style-01">
                <div class="container custom-container-01">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcrumb-content">
                                <h3 class="title">Contact us</h3>
                                <p class="details">We have professional alliance's with leading Universities and
                                    Colleges
                                    around the world.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- breadcrumb area end here  -->

            <!-- contact form start hare  -->
            <section class="contact-form-area-wrapper section-bottom-space">
                <div class="container custom-container-01">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="apply-form-inner">
                                <div class="row justify-content-between">
                                    <div class="col-lg-5">
                                        <div class="contact-address">
                                            <h3 class="title">Get in touch</h3>

                                            <ul class="ul contact-address-list">
                                                <li class="single-address-item">
                                                    <span class="icon-wrap color-01">
                                                        <i class="fa-sharp fa-solid fa-location-dot icon"></i>
                                                    </span>
                                                    <span class="text">2972 Westheimer Rd. Santa Ana, Illinoi
                                                        85486, India</span>
                                                </li>
                                                <li class="single-address-item">
                                                    <span class="icon-wrap color-02">
                                                        <i class="fa-solid fa-phone icon"></i>
                                                    </span>
                                                    <span class="text">(270) 555-0117 <br>
                                                        (270) 589-7395</span>
                                                </li>
                                                <li class="single-address-item">
                                                    <span class="icon-wrap color-03">
                                                        <i class="fa-solid fa-envelope-open icon"></i>
                                                    </span>
                                                    <span class="text">nathan.roberts@example.com <br>
                                                        headoffice@example.com</span>
                                                </li>
                                            </ul>

                                            <ul class="ul social-media-list style-01 color-02">
                                                <li class="single-social-item">
                                                    <a href="#" tabindex="-1">
                                                        <i class="fa-brands fa-instagram icon"></i>
                                                    </a>
                                                </li>
                                                <li class="single-social-item">
                                                    <a href="#" tabindex="-1">
                                                        <i class="fa-brands fa-facebook-f icon"></i>
                                                    </a>
                                                </li>
                                                <li class="single-social-item">
                                                    <a href="#" tabindex="-1">
                                                        <i class="fa-brands fa-youtube icon"></i>
                                                    </a>
                                                </li>
                                                <li class="single-social-item">
                                                    <a href="#" tabindex="-1">
                                                        <i class="fa-brands fa-linkedin-in icon"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-lg-7">
                                        <div class="contact-form">
                                            <form class="form">
                                                <div class="part">
                                                    <h5 class="title">Primary Information</h5>
                                                    <div class="form-element">
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <i class="fa-solid fa-user"></i>
                                                                <input type="text" placeholder="Full name" required="">
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <i class="fa-solid fa-envelope-open"></i>
                                                                <input type="email" placeholder="Email address"
                                                                    required="">
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div class="form-element">
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <i class="fa-solid fa-phone"></i>
                                                                <input type="tel" placeholder="Phone number"
                                                                    required="">
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <i class="fa-solid fa-user"></i>
                                                                <input type="text" placeholder="Full name" required="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-element">
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <textarea class="textarea"
                                                                    placeholder="Write description..."
                                                                    rows="10"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-submit text-right">
                                                    <button type="submit" class="btn-common btn-active">submit Message
                                                    </button>
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- contact form end hare  -->

            <!-- map area start hare  -->
            <div class="map-wrapper section-top-space">
                <iframe class="w-100"
                    src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d116838.78142003674!2d90.35554992826201!3d23.775466805757!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x3755c74493e3ad33%3A0xd8d84b987eddb825!2s199%2C%20Venus%20Complex%2C%2012th%20Floor%20Kha-199%2F2%2C%204%20Bir%20Uttam%20Rafiqul%20Islam%20Ave%2C%20Dhaka%201212!3m2!1d23.7754826!2d90.4255903!5e0!3m2!1sen!2sbd!4v1663127596682!5m2!1sen!2sbd"
                    height="510" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <!-- map area end hare  -->
        </div>
        <!-- about page end here  -->

        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            footer area start Here
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <footer class="footer-area style-01">
            <div class="footer-top">
                <div class="container custom-container-01">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="footer-widget widget widget_subscribe">
                                <div class="subscibe-wrapper">
                                    <div class="content-wrap">
                                        <div class="icon">
                                            <img src="assets/img/icon/newslater.png" alt="">
                                        </div>
                                        <div class="content">
                                            <h4 class="title">Subscribe our newsletter</h4>
                                            <p>Enter your mail address to get our updates, offer and study abroad
                                                related all updates</p>
                                        </div>

                                    </div>
                                    <div class="subscribe-form">
                                        <div class="form-group">
                                            <input type="text" name="fname" placeholder="Enter your Email..."
                                                class="form-control" required="" aria-required="true">
                                            <div class="btn-wrap">
                                                <a href="service-single.html" class="subscribe-btn">
                                                    <img src="assets/img/icon/bell.png" alt="">subscribe</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="footer-middle">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Important Links</h4>
                                    <ul>
                                        <li><a href="#">Terms and conditions</a></li>
                                        <li><a href="#">Disclaimer and copyright</a></li>
                                        <li><a href="#">Cookie policy</a></li>
                                        <li><a href="#">Privacy policy</a></li>
                                        <li><a href="#">Equality and diversity</a></li>
                                        <li><a href="#">Complaints procedure</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Site Highlight</h4>
                                    <ul>
                                        <li><a href="#">Student videos</a></li>
                                        <li><a href="#">Photo gallery</a></li>
                                        <li><a href="#">TSC prospectus</a></li>
                                        <li><a href="#">Student newsletter</a></li>
                                        <li><a href="#">Student portal</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Help Center</h4>
                                    <ul>
                                        <li><a href="#">Courses</a></li>
                                        <li><a href="#">How to apply for admission</a></li>
                                        <li><a href="#">Admission Documents</a></li>
                                        <li><a href="#">Frequently asked questions</a></li>
                                        <li><a href="#">Student accommodation</a></li>
                                        <li><a href="#">Student Jobs</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Services</h4>
                                    <ul>
                                        <li><a href="#">Counselling</a></li>
                                        <li><a href="#">Test Preparation</a></li>
                                        <li><a href="#">Admission</a></li>
                                        <li><a href="#">Education Loan</a></li>
                                        <li><a href="#">Visa Processing</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-6 col-sm-6">
                                <div class="footer-widget widget widget_nav_menu">
                                    <h4 class="widget-headline">Location</h4>
                                    <ul class="contact_info_list">
                                        <li class="single-info-item">
                                            <div class="icon">
                                                <img src="assets/img/icon/location-02.png" alt="">
                                            </div>
                                            <div class="details">
                                                8502 Preston Rd. Inglewood, Maine Bangladesh
                                            </div>
                                        </li>
                                        <li class="single-info-item">
                                            <div class="icon me-4">
                                                <img src="assets/img/icon/edu-award.png" alt="">
                                            </div>
                                            <div class="icon">
                                                <img src="assets/img/icon/iso.png" alt="">
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-area">
                <div class="container custom-container-01">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="copyright-area-inner">
                                <p>© 2022 Eduplan. All rights reserved | Developed By <span>Themeim</span></p>
                                <div class="footer-social-area">
                                    <ul class="social-icon-02">
                                        <li><a href="#0"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#0"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="#0"><i class="fab fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            footer area End Here
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    </main>

    <!-- back to top area start -->
    <!-- <div class="back-to-top">
        <span class="back-top"><i class="fa fa-angle-up"></i></span>
    </div> -->
    <!-- back to top area end -->

    <!-- Jquery Js -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <!-- bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/jquery.magnific-popup.js"></script>
    <!-- wow -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Nice Select -->
    <script src="assets/js/jquery.nice-select.js"></script>
    <!-- countdown -->
    <script src="assets/js/jquery.countdown.min.js"></script>
    <!-- semantic -->
    <script src="assets/js/datepicker.min.js"></script>
    <script src="assets/js/active.datepicker.min.js"></script>
    <!-- Odomiters -->
    <script src="assets/js/odometer.min.js"></script>
    <!-- Viewport Js -->
    <script src="assets/js/viewport.jquery.js"></script>
    <!-- slick Js -->
    <script src="assets/js/slick.min.js"></script>
    <!-- main js -->
    <script src="assets/js/main.js"></script>


</body>

</html>