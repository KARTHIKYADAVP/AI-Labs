<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AI Labs</title>
    <!-- favicon -->
    <link rel="icon" href="assets/img/favicon.png" sizes="20x20" type="image/png">
    <!-- animate -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- magnific popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!-- Nice Select -->
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <!-- Odomiters css -->
    <link rel="stylesheet" href="assets/css/odometer.css">
    <!-- fontawesome -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <!-- Slick Slider -->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive Css -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<!-- Developed by Shahadat Hossain -->

<body>
    <!-- preloader area start -->
    <div class="preloader" id="preloader">
        <div class="preloader-inner">
            <div class="loader">
            </div>
        </div>
    </div>
    <!-- preloader area end -->

    <!--  search Popup start -->
    <div class="body-overlay" id="body-overlay"></div>
    <div class="search-popup" id="search-popup">
        <form action="index.html" class="search-form">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Search.....">
            </div>
            <button class="close-btn border-none"><i class="fas fa-search"></i></button>
        </form>
    </div>
    <!-- Search Popup End -->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Nav Area Start Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <div class="nav-area-wrapper-relative">
        <nav class="navbar navbar-area navbar-expand-lg navigation-style-02">
            <div class="container custom-container custom-container-01">
                <div class="responsive-menu">
                    <div class="logo-wrapper">
                        <a href="index.php" class="logo">
                            <img src="assets/img/Logos/logo-black.svg" alt="">
                        </a>
                    </div>
                    <button class="navbar-toggler navbar-bs-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#themeim_main_menu" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="themeim_main_menu">
                    <ul class="navbar-nav">
                        <li class="menu-item-has-children current-menu-item">
                            <a href="#0">Home</a>
                            <ul class="sub-menu">
                               
                                <li><a href="index.php">Home Two</a></li>
                            </ul>
                        </li>

                        <li><a href="about-us.php">About Us</a></li>

                        <li class="menu-item-has-children">
                            <a href="#">Pages</a>
                            <ul class="sub-menu">
                                <li><a href="Our-services.php">Our Services</a></li>
                                <li><a href="services-details.php">Services Details</a></li>
                                <li><a href="our-team.php">Team</a></li>
                                <li><a href="instructors.php">Instructors</a></li>
                                <li><a href="about-instructor.php">About Instructor</a></li>
                                <li><a href="country-details.html">Country Details</a></li>
                                <li><a href="all-course.php">All Course</a></li>
                                <li><a href="all-course-widget.php">All Course with widget</a></li>
                                <li><a href="course-details.php">Course Details</a></li>
                                <li><a href="apply-online.php">Apply Online</a></li>
                                
                                
                               
                            </ul>
                        </li>

                       

                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="nav-right-content">
                    <div class="icon-part">
                        <ul>
                            <li id="search"><a href="#"><img src="assets/img/icon/search-icon.png" alt=""></a></li>
                        </ul>
                    </div>
                    <div class="btn-wrap">
                        <a href="#" class="btn-common nav-btn">Free consultation</a>
                    </div>
                </div>
            </div>
        </nav>
    </div>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Nav Area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->