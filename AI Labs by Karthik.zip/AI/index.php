<?php include "includes/header.php" ?>

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Cart area start Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <div class="cart-menu-overlay"></div>
    <div class="cart-menu-wrap">
        <div class="content-wrapper">
            <div class="cart-header">
                <div class="content">
                    <h6 class="title">Cart</h6>
                </div>
                <div class="close-btn-03">
                    <a href="javascript:void(0)">
                        <i class="flaticon-close"></i>
                    </a>
                </div>
            </div>
            <div class="cart-single-item">
                <div class="thumbnail">
                    <img src="assets/img/section-img/products/cart-02.png" alt="">
                    <i class="flaticon-close remove-cart"></i>
                </div>
                <div class="content">
                    <h6 class="title">Smart Air Bag</h6>
                    <p class="price">$225.00</p>
                </div>
            </div>
            <div class="cart-single-item">
                <div class="thumbnail">
                    <img src="assets/img/section-img/products/cart-03.png" alt="">
                    <i class="flaticon-close remove-cart"></i>
                </div>
                <div class="content">
                    <h6 class="title">Travel Suitcase</h6>
                    <p class="price">$375.00</p>
                </div>
            </div>
            <div class="cart-single-item">
                <div class="thumbnail">
                    <img src="assets/img/section-img/products/cart-04.png" alt="">
                    <i class="flaticon-close remove-cart"></i>
                </div>
                <div class="content">
                    <h6 class="title">Travel Slipping</h6>
                    <p class="price">$332.00</p>
                </div>
            </div>
            <div class="cart-footer">
                <div class="content">
                    <h4 class="subtotal">Subtotal</h4>
                    <p class="price">$932.00</p>
                </div>
            </div>
        </div>
    </div>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Cart area end Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Banner Area Start Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="banner-area home-two">
        <div class="container custom-container-01">
            <div class="banner-wrapper">
                <div class="row">
                    <div class="col-xl-6 col-lg-8">
                        <div class="banner-inner">
                            <p class="subtitle"><img src="assets/img/icon/celebrate-icon.png"
                                    alt="celebrate-icon">SPECIAL OFFER FIRST CUSTOMER</p>
                            <h1 class="title">Learn <span>anything</span> you want</h1>
                            <p>We’re a nonprofit with the mission to provide a free, world-classes education for anyone,
                                anywhere.</p>
                            <div class="header-btn">
                                <div class="btn-wrap">
                                    <a href="#0" class="btn-common flat-btn">Join for free</a>
                                </div>
                                <div class="btn-wrap desktop-right margin-left-20">
                                    <a href="#0" class="more-btn style-01">EXPLORE ALL COURSES</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-5">
                        <div class="thumbnail">
                            <img src="assets/img/shapes/Ellipse-03.png" alt="Ellipse" class="element-06">
                            <img src="assets/img/shapes/Ellipse-04.png" alt="Ellipse" class="element-07">
                            <img src="assets/img/shapes/Star-02.png" alt="Ellipse" class="element-08">
                            <img src="assets/img/shapes/Star-01.png" alt="Ellipse" class="element-09">
                            <img src="assets/img/header/two-person.png" class="banner-img" alt="Students">
                        </div>
                        <div class="enrolled">
                            <div class="icon">
                                <img src="assets/img/icon/people-icon.png" alt="">
                            </div>
                            <div class="content">
                                <h6 class="title">145k+ Enrolled</h6>
                                <p>Provide world class certificate</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Banner Area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Client Section area Start Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="client-section">
        <div class="container custom-container-01">
            <h4 class="client-title">We collaborate with <span>200+ leading universities and companies</span></h4>
            <div class="row justify-content-center">
                <div class="col-xl-12">
                    <div class="slick-main slick-main global-slick-init dots-style-03 dots-space" data-infinite="true"
                        data-arrows="true" data-fade="false" data-speed="500" data-slidesToShow="7"
                        data-slidesToScroll="1" data-swipeToSlide="true" data-autoplay="true" data-autoplaySpeed="2500"
                        data-dots="false" data-responsive='[
                                    {"breakpoint": 1200,"settings": {"slidesToShow": 5}},
                                    {"breakpoint": 992,"settings": {"slidesToShow": 5}},
                                    {"breakpoint": 650,"settings": {"slidesToShow": 5}},
                                    {"breakpoint": 600, "settings": {"slidesToShow": 4}}
                                    ]'>
                        <div class="slick-item">
                            <div class="brand-item">
                                <img src="assets/img/sections/client/koc.png" alt="koc university">
                            </div>
                        </div>

                        <div class="slick-item">
                            <div class="brand-item">
                                <img src="assets/img/sections/client/amity.png" alt="amity university">
                            </div>
                        </div>

                        <div class="slick-item">
                            <div class="brand-item">
                                <img src="assets/img/sections/client/kennesaw.png" alt="kennesaw university">
                            </div>
                        </div>

                        <div class="slick-item">
                            <div class="brand-item">
                                <img src="assets/img/sections/client/duke.png" alt="duke">
                            </div>
                        </div>

                        <div class="slick-item">
                            <div class="brand-item">
                                <img src="assets/img/sections/client/twiter.png" alt="twiter">
                            </div>
                        </div>

                        <div class="slick-item">
                            <div class="brand-item">
                                <img src="assets/img/sections/client/ibm.png" alt="ibm">
                            </div>
                        </div>

                        <div class="slick-item">
                            <div class="brand-item">
                                <img src="assets/img/sections/client/google.png" alt="google">
                            </div>
                        </div>

                        <div class="slick-item">
                            <div class="brand-item">
                                <img src="assets/img/sections/client/koc.png" alt="koc university">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Client Section area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Courses Section area Start Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="courses-section-area">
        <div class="container custom-container-01">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-wrapper d-flex justify-content-between">
                        <div class="theme-section-title">
                            <span class="subtitle">COURSES</span>
                            <h4 class="title">Discover Lifelong Learning</h4>
                        </div>
                        <div class="btn-wrap">
                            <a href="course.html" class="btn-common fill-btn">View all courses</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="slider-wrapper">
                        <div class="slick-main slick-main global-slick-init dots-style-03 dots-space"
                            data-infinite="true" data-arrows="true" data-fade="false" data-speed="500"
                            data-slidesToShow="3" data-slidesToScroll="1" data-swipeToSlide="true" data-autoplay="false"
                            data-autoplaySpeed="2500" data-dots="true" data-responsive='[
                                        {"breakpoint": 1367,"settings": {"slidesToShow": 3}},
                                        {"breakpoint": 992,"settings": {"slidesToShow": 2}},
                                        {"breakpoint": 600, "settings": {"slidesToShow": 1}}
                                        ]'>
                            <div class="slick-item">
                                <div class="course-single-item">
                                    <div class="thumbnail">
                                        <img src="assets/img/sections/courses/courses-01.png" alt="">
                                    </div>
                                    <div class="content">
                                        <p class="instructor">Harverd University</p>
                                        <h6 class="course-name">Become Ethereum Blockchain Developer</h6>
                                        <div class="ratings">
                                            <div class="icon">
                                                <img src="assets/img/icon/star.png" alt=""><span>4.8 (756)</span>
                                            </div>
                                            <h6 class="price">$25.50</h6>
                                        </div>
                                    </div>
                                    <div class="overlay-content">
                                        <p class="instructor">Leslie Alexander</p>
                                        <h6 class="course-name">Beginner friendly web development course A2Z</h6>
                                        <p>We have professional alliance's with leading Universities Colleges around
                                            the world.</p>
                                        <div class="duration">
                                            <div class="user"><img src="assets/img/icon/2people.png"
                                                    alt="group"><span>548796</span></div>
                                            <div class="hours"><img src="assets/img/icon/clock.png"
                                                    alt="clock-image"><span>23 hr 54 min</span> </div>
                                        </div>
                                        <div class="video-wrap">
                                            <a class="video-popup mfp-iframe"
                                                href="https://www.youtube.com/watch?v=c7XEhXZ_rsk">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path
                                                        d="M2.61196 0.352787C1.16948 -0.474644 0 0.203197 0 1.86558V14.1332C0 15.7973 1.16948 16.4742 2.61196 15.6476L13.3345 9.49828C14.7775 8.67055 14.7775 7.32952 13.3345 6.50199L2.61196 0.352787Z"
                                                        fill="white" />
                                                </svg>
                                            </a>
                                            <span>Watch Intro</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="slick-item">
                                <div class="course-single-item">
                                    <div class="thumbnail">
                                        <img src="assets/img/sections/courses/courses-02.png" alt="">
                                    </div>
                                    <div class="content">
                                        <p class="instructor">Esther Howard</p>
                                        <h6 class="course-name">Learn Python: The Complete Python </h6>
                                        <div class="ratings">
                                            <div class="icon">
                                                <img src="assets/img/icon/star.png" alt=""><span>4.8 (756)</span>
                                            </div>
                                            <h6 class="price">$25.50</h6>
                                        </div>
                                    </div>
                                    <div class="overlay-content">
                                        <p class="instructor">Leslie Alexander</p>
                                        <h6 class="course-name">Beginner friendly web development course A2Z</h6>
                                        <p>We have professional alliance's with leading Universities Colleges around
                                            the world.</p>
                                        <div class="duration">
                                            <div class="user"><img src="assets/img/icon/2people.png"
                                                    alt="group"><span>548796</span></div>
                                            <div class="hours"><img src="assets/img/icon/clock.png"
                                                    alt="clock-image"><span>23 hr 54 min</span> </div>
                                        </div>
                                        <div class="video-wrap">
                                            <a class="video-popup mfp-iframe"
                                                href="https://www.youtube.com/watch?v=c7XEhXZ_rsk">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path
                                                        d="M2.61196 0.352787C1.16948 -0.474644 0 0.203197 0 1.86558V14.1332C0 15.7973 1.16948 16.4742 2.61196 15.6476L13.3345 9.49828C14.7775 8.67055 14.7775 7.32952 13.3345 6.50199L2.61196 0.352787Z"
                                                        fill="white" />
                                                </svg>
                                            </a>
                                            <span>Watch Intro</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="slick-item">
                                <div class="course-single-item">
                                    <div class="thumbnail">
                                        <img src="assets/img/sections/courses/courses-03.png" alt="">
                                    </div>
                                    <div class="content">
                                        <p class="instructor">Leslie Alexander</p>
                                        <h6 class="course-name">Data Science and Machine Learning Bootcamp</h6>
                                        <div class="ratings">
                                            <div class="icon">
                                                <img src="assets/img/icon/star.png" alt=""><span>4.8 (756)</span>
                                            </div>
                                            <h6 class="price">$25.50</h6>
                                        </div>
                                    </div>
                                    <div class="overlay-content">
                                        <p class="instructor">Leslie Alexander</p>
                                        <h6 class="course-name">Beginner friendly web development course A2Z</h6>
                                        <p>We have professional alliance's with leading Universities Colleges around
                                            the world.</p>
                                        <div class="duration">
                                            <div class="user"><img src="assets/img/icon/2people.png"
                                                    alt="group"><span>548796</span></div>
                                            <div class="hours"><img src="assets/img/icon/clock.png"
                                                    alt="clock-image"><span>23 hr 54 min</span> </div>
                                        </div>
                                        <div class="video-wrap">
                                            <a class="video-popup mfp-iframe"
                                                href="https://www.youtube.com/watch?v=c7XEhXZ_rsk">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path
                                                        d="M2.61196 0.352787C1.16948 -0.474644 0 0.203197 0 1.86558V14.1332C0 15.7973 1.16948 16.4742 2.61196 15.6476L13.3345 9.49828C14.7775 8.67055 14.7775 7.32952 13.3345 6.50199L2.61196 0.352787Z"
                                                        fill="white" />
                                                </svg>
                                            </a>
                                            <span>Watch Intro</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="slick-item">
                                <div class="course-single-item">
                                    <div class="thumbnail">
                                        <img src="assets/img/sections/courses/courses-04.png" alt="">
                                    </div>
                                    <div class="content">
                                        <p class="instructor">Ralph Edwards</p>
                                        <h6 class="course-name">The Ultimate Drawing Course - Beginner
                                        </h6>
                                        <div class="ratings">
                                            <div class="icon">
                                                <img src="assets/img/icon/star.png" alt=""><span>4.8 (756)</span>
                                            </div>
                                            <h6 class="price">$25.50</h6>
                                        </div>
                                    </div>
                                    <div class="overlay-content">
                                        <p class="instructor">Leslie Alexander</p>
                                        <h6 class="course-name">Beginner friendly web development course A2Z</h6>
                                        <p>We have professional alliance's with leading Universities Colleges around
                                            the world.</p>
                                        <div class="duration">
                                            <div class="user"><img src="assets/img/icon/2people.png"
                                                    alt="group"><span>548796</span></div>
                                            <div class="hours"><img src="assets/img/icon/clock.png"
                                                    alt="clock-image"><span>23 hr 54 min</span> </div>
                                        </div>
                                        <div class="video-wrap">
                                            <a class="video-popup mfp-iframe"
                                                href="https://www.youtube.com/watch?v=c7XEhXZ_rsk">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path
                                                        d="M2.61196 0.352787C1.16948 -0.474644 0 0.203197 0 1.86558V14.1332C0 15.7973 1.16948 16.4742 2.61196 15.6476L13.3345 9.49828C14.7775 8.67055 14.7775 7.32952 13.3345 6.50199L2.61196 0.352787Z"
                                                        fill="white" />
                                                </svg>
                                            </a>
                                            <span>Watch Intro</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Courses Section area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Features Section Area Start Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="features-section home-two section-bottom-space">
        <div class="container custom-container-01">
            <div class="row">
                <div class="col-lg-5">
                    <div class="theme-section-title">
                        <span class="subtitle">ADVANTAGE FEATURES</span>
                        <h4 class="title">
                            Transform your life through education
                            <svg class="title-shape style-02 active" width="355" height="15" viewBox="0 0 355 15"
                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path class="path" d="M351.66 12.6362C187.865 -6.32755 49.6478 6.37132 3.41142 12.6362"
                                    stroke="#764AF1" stroke-width="3" stroke-linecap="square"></path>
                                <path class="path" d="M351.66 13C187.865 -5.96378 49.6478 6.73509 3.41142 13"
                                    stroke="#764AF1" stroke-width="3" stroke-linecap="square"></path>
                                <path class="path" d="M2.5 5.5C168.5 2.0001 280.5 -1.49994 352.5 8.49985"
                                    stroke="#FFC44E" stroke-width="3" stroke-linecap="square"></path>
                            </svg>
                        </h4>
                        <p>The head office of Eduplan is located in India which helps all Indian students to get
                            admission into top-ranked universities from the United Kingdom, USA, Australia,
                            Canada,Germany and Sweden.</p>
                    </div>

                    <div class="icon-box-with-text-wrap">
                        <ul class="ul icon-box-with-text style-01">
                            <li class="single-icon-box-with-text">
                                <div class="icon-wrap color-01">
                                    <img src="assets/img/icon/icon-and-text/key.svg" alt="">
                                </div>
                                <div class="content">
                                    <p class="text">Get life-time free access with one time payment in our
                                        courses plan. Easy
                                        &amp;
                                        simple!
                                    </p>
                                </div>
                            </li>
                            <li class="single-icon-box-with-text style-02">
                                <div class="icon-wrap color-02">
                                    <img src="assets/img/icon/icon-and-text/board.svg" alt="">
                                </div>
                                <div class="content">
                                    <p class="text">We find the expert tuotor with huge teaching experience
                                    </p>
                                </div>
                            </li>
                            <li class="single-icon-box-with-text style-03">
                                <div class="icon-wrap color-03">
                                    <img src="assets/img/icon/icon-and-text/monitor.svg" alt="">
                                </div>
                                <div class="content">
                                    <p class="text">We present worldclass courses with practical learning
                                        tasks
                                        that make
                                        students more
                                        confident.</p>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div class="btn-wrap margin-top-60">
                        <a href="courses.html" class="btn-common fill-btn">Start learning today</a>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1">
                    <div class="thumbnail">
                        <img src="assets/img/sections/about/student-discuse.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Features Section Area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Counter Section Area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <div class="section-top-space">
        <div class="counter-section-area bg-color-x">
            <div class="container custom-container-01">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="counter-section-inner style-01">
                            <div class="single-counterup">
                                <div class="image-wrap">
                                    <img src="assets/img/sections/client/people-group.png" alt="">
                                </div>
                                <div class="content-wrap">
                                    <div class="odo-area">
                                        <h3 class="odometer odo-title" data-odometer-final="458712">0</h3>
                                    </div>
                                    <div class="content">
                                        <h6 class="subtitle">More then students</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="single-counterup">
                                <div class="image-wrap">
                                    <img src="assets/img/sections/client/customer-care.png" alt="">
                                </div>
                                <div class="content-wrap">
                                    <div class="odo-area">
                                        <h3 class="odometer odo-title" data-odometer-final="211">0</h3>
                                    </div>
                                    <div class="content">
                                        <h6 class="subtitle">Total consultants</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="single-counterup">
                                <div class="image-wrap">
                                    <img src="assets/img/sections/client/graduation.png" alt="">
                                </div>
                                <div class="content-wrap">
                                    <div class="odo-area">
                                        <h3 class="odometer odo-title" data-odometer-final="425">0</h3>
                                    </div>
                                    <div class="content">
                                        <h6 class="subtitle">Total courses</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="single-counterup">
                                <div class="image-wrap">
                                    <img src="assets/img/sections/client/world.png" alt="">
                                </div>
                                <div class="content-wrap">
                                    <div class="odo-area">
                                        <h3 class="odometer odo-title" data-odometer-final="32">0</h3>
                                    </div>
                                    <div class="content">
                                        <h6 class="subtitle">Countries</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Counter Section Area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Category Section Area Start Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="category-section-area">
        <div class="container custom-container-01">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="theme-section-title desktop-center">
                        <span class="subtitle">CATEGORY</span>
                        <h4 class="title">Featured Topic by Category</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-4">
                    <div class="category-item">
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/python.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Python</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/cyber-cell.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Cyber Security</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/heacker.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Ethical Hacking</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/monitor.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">UI UX Design</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="category-item">
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/graphic.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Graphic Design</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/camera.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Photography</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/drawing-pen.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Drawing</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/managenent.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Business management</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="category-item">
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/coding.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Web Development</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/machine-learning.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Machine Learning</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/heacker.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Ethical Hacking</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                        <div class="categories-inner">
                            <div class="content-wrap">
                                <div class="icon">
                                    <img src="assets/img/sections/categories/calculator.png" alt="">
                                </div>
                                <div class="content">
                                    <h4 class="title">Financial Analysis</h4>
                                    <p>458 Courses</p>
                                </div>
                            </div>
                            <div class="icon">
                                <img src="assets/img/icon/arrow-right.svg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Category Section Area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Features Section Area Start Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="features-section style-01 margin-top-110 home-two">
        <div class="container custom-container-01">
            <div class="row align-items-center row-reverse">
                <div class="col-lg-6">
                    <div class="thumbnail">
                        <img src="assets/img/sections/about/conference.png" alt="">
                    </div>
                </div>
                <div class="col-lg-5 offset-lg-1">
                    <div class="theme-section-title">
                        <span class="subtitle">ADVANTAGE FEATURES</span>
                        <h4 class="title">
                            A faster way for your employees to grow <br> and upskill
                            <svg class="title-shape style-03 active" width="255" height="15" viewBox="0 0 355 15"
                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path class="path" d="M351.66 12.6362C187.865 -6.32755 49.6478 6.37132 3.41142 12.6362"
                                    stroke="#764AF1" stroke-width="3" stroke-linecap="square"></path>
                                <path class="path" d="M351.66 13C187.865 -5.96378 49.6478 6.73509 3.41142 13"
                                    stroke="#764AF1" stroke-width="3" stroke-linecap="square"></path>
                                <path class="path" d="M2.5 5.5C168.5 2.0001 280.5 -1.49994 352.5 8.49985"
                                    stroke="#FFC44E" stroke-width="3" stroke-linecap="square"></path>
                            </svg>
                        </h4>
                        <p>Our range of solutions has something to offer all businesses and organizations. Whether
                            you’re a non-profit or a commercial entity, we can tailor a plan for your needs.</p>
                        <p>Our range of solutions has something to offer all businesses and organizations. Whether
                            you’re a non-profit or a commercial entity, we can tailor a plan for your needs.</p>
                    </div>
                    <div class="btn-wrap margin-top-60">
                        <a href="courses.html" class="btn-common fill-btn">Eduplan for business</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Features Section Area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
       Testimonial Section Area Start Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="testimonial-section margin-top-110">
        <img src="assets/img/shapes/paper-roll.png" class="testimonial-shape" alt="Graduation Paper">
        <div class="container custom-container-01">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="theme-section-title desktop-center text-center">
                        <h4 class="title">Students feedback</h4>
                        <p>We have quality partners in variety of destinations around the globe.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="slick-main slick-main global-slick-init dots-style-03 dots-space" data-infinite="true"
                        data-arrows="true" data-fade="false" data-speed="500" data-slidesToShow="3"
                        data-slidesToScroll="1" data-swipeToSlide="true" data-autoplay="true" data-autoplaySpeed="2500"
                        data-dots="true" data-responsive='[
                                    {"breakpoint": 1367,"settings": {"slidesToShow": 3}},
                                    {"breakpoint": 992,"settings": {"slidesToShow": 2}},
                                    {"breakpoint": 600, "settings": {"slidesToShow": 1}}
                                    ]'>
                        <div class="slick-item">
                            <div class="testimonial-single-items style-01">
                                <div class="feedback-wrap">
                                    <ul class="ul feedback-icon-list">
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                    </ul>
                                </div>

                                <div class="content">
                                    <p class="feedback-text">“I able to prove potential employers that i have a solid
                                        understanding of
                                        computers &
                                        hardware- and started to receive real, viable job offers”.</p>
                                </div>

                                <div class="client-and-quote">
                                    <div class="client-details">
                                        <div class="thumb">
                                            <img src="assets/img/sections/testimonial/tesi-01.png" alt="">
                                        </div>
                                        <div class="content">
                                            <p class="client-name">Savannah Nguyen</p>
                                            <p class="designation">Central African Republic</p>
                                        </div>
                                    </div>

                                    <div class="quote">
                                        <i class="fa-solid fa-quote-right icon"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="slick-item">
                            <div class="testimonial-single-items style-01">
                                <div class="feedback-wrap">
                                    <ul class="ul feedback-icon-list">
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                    </ul>
                                </div>

                                <div class="content">
                                    <p class="feedback-text">“I able to prove potential employers that i have a solid
                                        understanding of
                                        computers &
                                        hardware- and started to receive real, viable job offers”.</p>
                                </div>

                                <div class="client-and-quote">
                                    <div class="client-details">
                                        <div class="thumb">
                                            <img src="assets/img/sections/testimonial/testi-02.png" alt="">
                                        </div>
                                        <div class="content">
                                            <p class="client-name">Savannah Nguyen</p>
                                            <p class="designation">Central African Republic</p>
                                        </div>
                                    </div>

                                    <div class="quote">
                                        <i class="fa-solid fa-quote-right icon"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="slick-item">
                            <div class="testimonial-single-items style-01">
                                <div class="feedback-wrap">
                                    <ul class="ul feedback-icon-list">
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                    </ul>
                                </div>

                                <div class="content">
                                    <p class="feedback-text">“I able to prove potential employers that i have a solid
                                        understanding of
                                        computers &
                                        hardware- and started to receive real, viable job offers”.</p>
                                </div>

                                <div class="client-and-quote">
                                    <div class="client-details">
                                        <div class="thumb">
                                            <img src="assets/img/sections/testimonial/testi-03.png" alt="">
                                        </div>
                                        <div class="content">
                                            <p class="client-name">Savannah Nguyen</p>
                                            <p class="designation">Central African Republic</p>
                                        </div>
                                    </div>

                                    <div class="quote">
                                        <i class="fa-solid fa-quote-right icon"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="slick-item">
                            <div class="testimonial-single-items style-01">
                                <div class="feedback-wrap">
                                    <ul class="ul feedback-icon-list">
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                        <li class="single-feedback-item">
                                            <i class="fas fa-star icon"></i>
                                        </li>
                                    </ul>
                                </div>

                                <div class="content">
                                    <p class="feedback-text">“I able to prove potential employers that i have a solid
                                        understanding of
                                        computers &
                                        hardware- and started to receive real, viable job offers”.</p>
                                </div>

                                <div class="client-and-quote">
                                    <div class="client-details">
                                        <div class="thumb">
                                            <img src="assets/img/sections/testimonial/testi-03.png" alt="">
                                        </div>
                                        <div class="content">
                                            <p class="client-name">Savannah Nguyen</p>
                                            <p class="designation">Central African Republic</p>
                                        </div>
                                    </div>

                                    <div class="quote">
                                        <i class="fa-solid fa-quote-right icon"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
       Testimonial Section Area End Here
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            News Section Area Start Here
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="news-section-area margin-top-110">
        <div class="container custom-container-01">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="theme-section-title desktop-center text-center">
                        <span class="subtitle">EDUPLAN UPDATES</span>
                        <h4 class="title">Eduplan Latest Blog</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-4">
                    <div class="blog-grid-item">
                        <div class="thumbnail">
                            <img src="assets/img/sections/blog/blog-01.png" alt="" class="border-radius-20">
                        </div>
                        <div class="content">
                            <ul class="post-categories">
                                <li><img src="assets/img/icon/calander.png" alt="">19th Jan 2022</li>
                                <li>12 noon to 4 pm</li>
                            </ul>
                            <h4 class="title">Overseas Education Fair Amravati 2023</h4>
                            <div class="btn-wrap">
                                <a href="#0" class="more-btn">Read More <i class="fa-solid fa-angle-right icon"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="blog-grid-item">
                        <div class="thumbnail">
                            <img src="assets/img/sections/blog/blog-01.png" alt="">
                        </div>
                        <div class="content">
                            <ul class="post-categories">
                                <li><img src="assets/img/icon/calander.png" alt="">19th Jan 2022</li>
                                <li>12 noon to 4 pm</li>
                            </ul>
                            <h4 class="title">Overseas Education Fair Amravati 2023</h4>
                            <div class="btn-wrap">
                                <a href="#0" class="more-btn">Read More <i class="fa-solid fa-angle-right icon"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="blog-grid-item">
                        <div class="thumbnail">
                            <img src="assets/img/sections/blog/blog-01.png" alt="">
                        </div>
                        <div class="content">
                            <ul class="post-categories">
                                <li><img src="assets/img/icon/calander.png" alt="">19th Jan 2022</li>
                                <li>12 noon to 4 pm</li>
                            </ul>
                            <h4 class="title">Overseas Education Fair Amravati 2023</h4>
                            <div class="btn-wrap">
                                <a href="#0" class="more-btn">Read More <i class="fa-solid fa-angle-right icon"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            News Section Area End Here
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <?php include "includes/footer.php" ?>
    

    